<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12">
        <div class="card page-title-content">
            <div class="card-body">
                <p class="card-text"><strong class="text-primary"><?php echo e(auth()->user()->greetings()); ?></strong>
                    <span> <?php echo e(auth()->user()->name); ?></span>
                </p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-3 col-lg-4 col-xxl-4">
        <div class="card balance-widget">
            <div class="card-header border-0 py-0">
                <h4 class="card-title">Your Portfolio </h4>
            </div>
            <div class="card-body">
                <div class="balance-widget">
                    <ul class="list-unstyled">
                        <li class="media">
                            <i class="cc BTC mr-3"></i>
                            <div class="media-body">
                                <h5 class="m-0">Bitcoin</h5>
                            </div>
                            <div class="text-right">
                                <h5><?php echo e(auth()->user()->address()['amount']); ?></h5>
                                <span><?php echo e(auth()->user()->address()['value']); ?></span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-6 col-lg-8 col-xxl-8">
        <div class="card">
            <iframe src="https://widget.coinlib.io/widget?type=single_v2&theme=light&coin_id=859&pref_coin_id=1505" width="100%" height="210px" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe>
        </div>
    </div>
    <div class="col-xl-3 col-lg-12 col-xxl-12">
        <div class="card">
            <div class="card-header border-0 py-0">
                <h4 class="card-title">Today's Rate</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-12 col-lg-6 col-xxl-6">
                        <div class="widget-card">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="widget-stat">
                                    <div class="coin-title">
                                        <span><i class="cc BTC"></i></span>
                                        <h5 class="d-inline-block ml-2 mb-3">Bitcoin <span>(24h)</span>
                                        </h5>
                                    </div>
                                    <h4><?php echo e(auth()->user()->address()['rate']); ?>

                                    </h4>
                                </div>
                                <div id="btcChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <iframe src="https://widget.coinlib.io/widget?type=full_v2&theme=light&cnt=6&pref_coin_id=1505&graph=yes" width="100%" height="409px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe> -->
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-3 col-lg-4 col-xxl-4">
        <div class="card">
            <div class="card-header border-0 py-0">
                <h4 class="card-title">Send / Receive</h4>
            </div>
            <div class="card-body">
                <div class="buy-sell-widget">
                    <form method="post" action="<?php echo e(route('send')); ?>" class="currency_validate">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="mr-sm-2">Wallet</label>
                            <div class="input-group mb-3">
                                <select id="send-currency" class="form-control <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="currency" value="<?php echo e(old('currency')); ?>" required>
                                    <option data-display="Bitcoin" value="bitcoin">Bitcoin
                                    </option>
                                </select>
                                <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="mr-sm-2">Recipient Address</label>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control <?php $__errorArgs = ['recipient_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="recipient_address" value="<?php echo e(old('recipient_address')); ?>" value="BTC address">
                                <?php $__errorArgs = ['recipient_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="mr-sm-2">Amount to Buy</label>
                            <div class="input-group">
                                <div class="input-group">
                                    <input type="text" id="send-val" class="form-control <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onkeypress="return isNumberKey(this, event);" name="value" value="<?php echo e(old('value')); ?>" required placeholder="0.0214 BTC">
                                    <input type="text" id="send-amt" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onkeypress="return isNumberKey(this, event);" name="amount" value="<?php echo e(old('amount')); ?>" required placeholder="125.00 USD">
                                </div>
                                <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="btn-group">
                            <button type="submit" class="btn btn-primary">Send</button>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#receive">Receive</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-9 col-lg-8 col-xxl-8">
        <div class="card">
            <div class="card-header border-0 py-0">
                <h4 class="card-title">Recent Activities</h4>
                <a href="<?php echo e(route('activities')); ?>">View More </a>
            </div>
            <div class="card-body">
                <?php if(empty(auth()->user()->address()['trnx'])): ?>
                <p>All your activities will appear here</p>
                <?php else: ?>
                <div class="transaction-table">
                    <div class="table-responsive">
                        <table class="table mb-0 table-responsive-sm">
                            <tbody>
                                <?php $__currentLoopData = auth()->user()->address()['trnx']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($act->hash); ?>

                                    </td>
                                    <?php if(!$act->value): ?>
                                    <td class="text-primary"><a href="https://www.blockchain.com/btc/tx/<?php echo e($act->hash); ?>" target="_blank">Explorer <i class="la la-external-link"></i></a></td>
                                    <?php else: ?>
                                    <td class="text-primary"><?php echo e($act->value); ?></td>
                                    <?php endif; ?>
                                </tr>
                                <?php if($key == 4): ?> <?php break; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bonaventureumolu/Documents/Workspace/Devburna/coinchoppamax/resources/views/dashboard/home.blade.php ENDPATH**/ ?>
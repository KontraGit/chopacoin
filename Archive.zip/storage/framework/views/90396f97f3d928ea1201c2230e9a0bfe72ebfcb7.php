<?php $__env->startSection('content'); ?>
<div class="card-header justify-content-center">
    <h4 class="card-title">Sign in</h4>
</div>
<div class="card-body p-4">
    <form method="POST" action="<?php echo e(route('login')); ?>" name="myform" class="signin_validate">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="hello@example.com" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="current-password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-row d-flex justify-content-between mt-4 mb-2">
            <div class="form-group mb-0">
                <label class="toggle">
                    <input class="toggle-checkbox" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    <span class="toggle-switch"></span>
                    <span class="toggle-label">Remember me</span>
                </label>
            </div>
            <?php if(Route::has('password.request')): ?>
            <div class="form-group mb-0">
                <a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
            </div>
            <?php endif; ?>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-success btn-block">Sign in</button>
        </div>
    </form>
    <?php if(Route::has('register')): ?>
    <div class="new-account mt-3">
        <p>Don't have an account? <a class="text-primary" href="<?php echo e(route('register')); ?>">Sign up</a></p>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bonaventureumolu/Documents/Workspace/Devburna/coinchoppamax/resources/views/auth/login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-body">
                    <h1 class="display-1 font-weight-bolder">500</h1>
                    <h3>Internal Server Error</h3>
                    <p class="card-text">The server encountered an internal error or misconfiguration <br> and was unable to complete your request.</p>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-lg">Try Again</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bonaventureumolu/Documents/Workspace/Devburna/coinchoppamax/resources/views/errors/500.blade.php ENDPATH**/ ?>